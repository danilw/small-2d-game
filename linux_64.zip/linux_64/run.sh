#!/bin/sh
file_path=`readlink -f -n "$0"`
path=`dirname "$file_path"`
cd "$path/"
LD_LIBRARY_PATH="$path/" "$path/2dgamii"
